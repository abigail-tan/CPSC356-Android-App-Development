Abby Tan
2276413
tan177@mail.chapman.edu
Assignment 3 - Class Records

Description:
This app allow the user to add classes along with their student rosters and to edit 
whatever classes that need to be changed.

Notes:
-run on a Pixel2XL emulator
