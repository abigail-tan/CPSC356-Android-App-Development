package edu.chapman.tan177.classrecords;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.util.ArrayList;

public class StudentCreateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_create);

        final Button addStuBtn = findViewById(R.id.addStd);
        final EditText stuName = findViewById(R.id.stuName);

        addStuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<String> temp = MainActivity.classDict.get(ViewClassActivity.classInfo);
                temp.add(stuName.getText().toString());
                MainActivity.classDict.put(ViewClassActivity.classInfo,temp);

                Intent intent = new Intent(StudentCreateActivity.this, ViewActivity.class);
                startActivity(intent);
            }
        });
    }
}
