package edu.chapman.tan177.classrecords;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public static Map<String,ArrayList> classDict;
    public static ArrayList<String> classList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        classDict = new HashMap<String,ArrayList>();
        classList = new ArrayList<String>();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button createBtn = findViewById(R.id.editBtn);


        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CreateActivity.class);
                startActivity(intent);
            }
        });
    }

}
