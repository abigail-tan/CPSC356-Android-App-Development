package edu.chapman.tan177.classrecords;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class CreateActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        final Button createBtn = findViewById(R.id.createBtn);
        final EditText classNameTxt = findViewById(R.id.classNameTxt);
        final EditText classIdTxt = findViewById(R.id.classIdNum);
        final EditText studentRoster = findViewById(R.id.studentList);

        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String className = classNameTxt.getText().toString()+" - "+classIdTxt.getText().toString();
                MainActivity.classList.add(className);
                String stdNames = studentRoster.getText().toString();
                ArrayList<String> stuNames = new ArrayList<String>(Arrays.asList(stdNames.split(", ")));

                MainActivity.classDict.put(className,stuNames);

                classNameTxt.setText("");
                classIdTxt.setText("");
                studentRoster.setText("");


                Intent intent = new Intent(CreateActivity.this, ViewActivity.class);
                startActivity(intent);
            }
        });
    }

}