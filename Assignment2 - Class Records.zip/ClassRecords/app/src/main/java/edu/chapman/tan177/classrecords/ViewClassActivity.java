package edu.chapman.tan177.classrecords;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class ViewClassActivity extends AppCompatActivity {

    public static String classInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_class);

        int id = ViewActivity.id;
        classInfo = MainActivity.classList.get(id);
        String[] classInf = classInfo.split(" - ");

        final TextView className = findViewById(R.id.className);
        final TextView classId = findViewById(R.id.classId);
        final TextView studentList = findViewById(R.id.studentList);
        final Button editBtn = findViewById(R.id.editBtn);
        final Button addStuBtn = findViewById(R.id.addStudentBtn);
        final Button createBtn = findViewById(R.id.createBtn);
        final Button viewBtn = findViewById(R.id.viewBtn);


        className.setText(classInf[0]);
        classId.setText(classInf[1]);

        ArrayList<String> tempStuList = MainActivity.classDict.get(classInfo);
        String stuList = "";
        for(int i = 0; i < tempStuList.size(); ++i)
        {
            stuList += tempStuList.get(i)+"\n";
        }
        studentList.setText(stuList);

        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(ViewClassActivity.this, EditActivity.class);
                startActivity(intent);
            }
        });

        addStuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewClassActivity.this, StudentCreateActivity.class);
                startActivity(intent);
            }
        });
        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(ViewClassActivity.this, CreateActivity.class);
                startActivity(intent);
            }
        });

        viewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(ViewClassActivity.this, ViewActivity.class);
                startActivity(intent);
            }
        });
    }
}
