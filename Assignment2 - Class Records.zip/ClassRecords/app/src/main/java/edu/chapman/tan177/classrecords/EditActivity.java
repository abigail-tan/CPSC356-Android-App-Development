package edu.chapman.tan177.classrecords;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Arrays;

public class EditActivity extends AppCompatActivity {

    public static int classId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        final Button editBtn = findViewById(R.id.editBtn);
        final EditText classNameTxt = findViewById(R.id.classNameTxt);
        final EditText classIdTxt = findViewById(R.id.classIdNum);
        final EditText studentRoster = findViewById(R.id.studentList);

        int id = ViewActivity.id;
        String classInfo = MainActivity.classList.get(id);

        classId = MainActivity.classList.indexOf(classInfo);
        ViewActivity.viewLayout.removeView(ViewActivity.buttons.get(classId));
        MainActivity.classDict.remove(classInfo);
        MainActivity.classList.remove(classId);

        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String className = classNameTxt.getText().toString() + " - " + classIdTxt.getText().toString();
                MainActivity.classList.add(className);
                String stdNames = studentRoster.getText().toString();
                ArrayList<String> stuNames = new ArrayList<String>(Arrays.asList(stdNames.split(", ")));

                MainActivity.classDict.put(className, stuNames);

                classNameTxt.setText("");
                classIdTxt.setText("");
                studentRoster.setText("");


                Intent intent = new Intent(EditActivity.this, ViewActivity.class);
                startActivity(intent);
            }
        });
    }
}
