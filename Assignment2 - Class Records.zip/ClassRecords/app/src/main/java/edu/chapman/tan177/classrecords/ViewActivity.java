package edu.chapman.tan177.classrecords;

import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import java.util.ArrayList;

public class ViewActivity extends AppCompatActivity {

    public static int id;
    public static ArrayList<Button> buttons;
    public static boolean needDelete;
    public static LinearLayout viewLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        viewLayout = findViewById(R.id.activity_view);
        buttons = new ArrayList<Button>();
        final Button createBtn = findViewById(R.id.createBtn);

        for(int i = 0; i< MainActivity.classList.size(); ++i)
        {
            final Button btn = new Button(ViewActivity.this);
            btn.setHeight(30);
            btn.setText(MainActivity.classList.get(i).toString());
            btn.setId(i);
            buttons.add(btn);
            viewLayout.addView(btn);

        }

        for(int i=0; i<buttons.size(); ++i)
        {
            buttons.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    id = v.getId();
                    Intent intent = new Intent(ViewActivity.this, ViewClassActivity.class);
                    startActivity(intent);
                }
            });
        }

        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(ViewActivity.this, CreateActivity.class);
                startActivity(intent);
            }
        });

    }
}

