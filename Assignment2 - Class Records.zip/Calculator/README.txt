Abby Tan
2276413
tan177@mail.chapman.edu
Assignment 1 - Calculator

Description:
This app is a standard, basic calculator.


Notes/Comments:
-use a Pixel2XL emulator
-if you type in a number and click the equals sign without inputting an operation 
and second number, the app will crash
-if you type in an operation then an equals without a second number and only have a 
first number, it'll crash
-2+2=4 +2=6 works but 2+2+2 = does not work
-clr is to delete the whole entry, del is to delete one character