package edu.chapman.tan177.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ArrayList<Float> myList = new ArrayList();
    ArrayList<Float> tempList = new ArrayList();

    boolean first = true;

    float tempInt;

    boolean plus, minus, multiply, divide;

    String pastAct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //the next 20 lines connects these buttons to their respective button reference in the XML file
        final Button zero = findViewById(R.id.zero);
        final Button one = findViewById(R.id.one);
        final Button two = findViewById(R.id.two);
        final Button three = findViewById(R.id.three);
        final Button four = findViewById(R.id.four);
        final Button five = findViewById(R.id.five);
        final Button six = findViewById(R.id.six);
        final Button seven = findViewById(R.id.seven);
        final Button eight = findViewById(R.id.eight);
        final Button nine = findViewById(R.id.nine);
        final Button decimal = findViewById(R.id.decimal);
        final Button addition = findViewById(R.id.addition);
        final Button subtraction = findViewById(R.id.subtraction);
        final Button multiplication = findViewById(R.id.multiplication);
        final Button division = findViewById(R.id.division);
        final Button clr = findViewById(R.id.clr);
        final Button clrOne = findViewById(R.id.clrOne);
        final Button equals = findViewById(R.id.equals);
        final EditText edt = findViewById(R.id.edt);
        final EditText historyText = findViewById(R.id.historyText);

        //the .setOnClickListeners for 0-9 take care of the user input for numbers
            //stores the number in variable a and updates the numbers on the textbox
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt.setText(edt.getText() + "1");
            }
        });

        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt.setText(edt.getText() + "2");
            }
        });

        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt.setText(edt.getText() + "3");
            }
        });

        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt.setText(edt.getText() + "4");
            }
        });

        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt.setText(edt.getText() + "5");
            }
        });

        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt.setText(edt.getText() + "6");
            }
        });

        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt.setText(edt.getText() + "7");
            }
        });

        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt.setText(edt.getText() + "8");
            }
        });

        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt.setText(edt.getText() + "9");
            }
        });

        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt.setText(edt.getText() + "0");
            }
        });

        //takes care of decimal button and makes sure the user doesn't input more than one decimal
        decimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String temp = edt.getText().toString();
                int t = temp.length();
                char tempL = temp.toCharArray()[t-1];
                if(tempL != '.')
                    edt.setText(edt.getText() + ".");
            }
        });

            //the next 4 .setOnClickListeners take care of pushing the operation buttons and clears the textbox
            addition.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (edt.getText().toString() == null) {
                        edt.setText("");
                    } else {
                        myList.add(Float.parseFloat(edt.getText() + ""));
                        plus = true;
                        edt.setText(null);
                    }
                }
            });

            subtraction.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myList.add(Float.parseFloat(edt.getText() + ""));
                    minus = true;
                    edt.setText(null);
                }
            });

            multiplication.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myList.add(Float.parseFloat(edt.getText() + ""));
                    multiply = true;
                    edt.setText(null);
                }
            });

            division.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myList.add(Float.parseFloat(edt.getText() + ""));
                    divide = true;
                    edt.setText(null);
                }
            });

            //carries out all the operations
            //this is where the number lists are used in situations where the user wants to
            //calculate an operation with more than 2 numbers
            equals.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myList.add(Float.parseFloat(edt.getText() + ""));
                    int listSize = myList.size();
                    int tempSize = tempList.size();
                    float result;
                    if(first == true){
                        if(plus){
                            tempList.add(myList.get(listSize-2) + myList.get(listSize-1));
                            pastAct = "+";
                            edt.setText(tempList.get(tempSize).toString() +"");
                            plus = false;
                        }
                        if(minus){
                            tempList.add(myList.get(listSize-2) - myList.get(listSize-1));
                            pastAct = "-";
                            edt.setText(tempList.get(tempSize).toString() +"");
                            minus = false;
                        }
                        if(multiply){
                            tempList.add(myList.get(listSize-2) * myList.get(listSize-1));
                            pastAct = "*";
                            edt.setText(tempList.get(tempSize).toString() +"");
                            multiply = false;
                        }
                        if(divide){
                            tempList.add(myList.get(listSize-2) / myList.get(listSize-1));
                            pastAct = "/";
                            edt.setText(tempList.get(tempSize).toString() +"");
                            divide = false;
                        }
                        //prints the previous operation in the textbox above the main textbox
                        String past = myList.get(listSize-2)+" "+pastAct+" "+myList.get(listSize-1)+" = "+tempList.get(tempSize);
                        historyText.setText(past);
                        first = false;
                    }
                    else{
                        if(plus){
                            tempInt = tempList.get(tempSize-1) + myList.get(listSize-1);
                            pastAct = "+";
                            edt.setText(tempInt+"");
                            plus=false;
                            tempList.add(tempInt);
                        }
                        if(minus){
                            tempInt = tempList.get(tempSize-1) - myList.get(listSize-1);
                            pastAct = "-";
                            edt.setText(tempInt+"");
                            minus=false;
                            tempList.add(tempInt);
                        }
                        if(multiply){
                            tempInt = tempList.get(tempSize-1) * myList.get(listSize-1);
                            pastAct = "*";
                            edt.setText(tempInt+"");
                            multiply=false;
                            tempList.add(tempInt);
                        }
                        if(divide){
                            tempInt = tempList.get(tempSize-1) / myList.get(listSize-1);
                            tempInt /= myList.get(listSize-1);
                            pastAct = "/";
                            edt.setText(tempInt+"");
                            divide=false;
                            tempList.add(tempInt);
                        }
                        //prints the previous operation in the textbox above the main textbox
                        String past = tempList.get(tempSize-1) +" "+pastAct+" "+myList.get(listSize-1)+" = "+tempInt;
                        historyText.setText(past);
                    }
                }
            });


        //takes care of the clear all button
        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //int listSize = myList.size();
                //int tempSize = tempList.size();
                edt.setText("");
                /*if(first == true)
                {
                    //prints the previous operation in the textbox above the main textbox
                    String past = myList.get(listSize-2)+" "+pastAct+" "+myList.get(listSize-1)+" = "+tempList.get(tempSize);
                    historyText.setText(past);
                }
                else
                {
                    //prints the previous operation in the textbox above the main textbox
                    String past = tempList.get(tempSize-2)+" "+pastAct+" "+myList.get(listSize-1)+" = "+tempList.get(tempSize-1);
                    historyText.setText(past);
                }*/
                first=true;
            }
        });

        //deletes only one character
        clrOne.setOnClickListener(new View.OnClickListener(){
           @Override
           public void onClick(View v){
               String temp = edt.getText().toString();
               if(temp.length() > 0){
                   temp = temp.substring(0,temp.length()-1);
                   edt.setText(temp);
               }
           }
        });

    }
}
