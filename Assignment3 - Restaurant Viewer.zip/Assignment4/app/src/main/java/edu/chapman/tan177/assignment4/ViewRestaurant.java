package edu.chapman.tan177.assignment4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

public class ViewRestaurant extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_restaurant);

        int id = MainActivity.id;
        Restaurant temp = Restaurant.restaurantList.get(id);
        final Button backBtn = findViewById(R.id.back);

        final TextView name = findViewById(R.id.name);
        final TextView phone = findViewById(R.id.phone);
        final TextView web = findViewById(R.id.web);
        final TextView category = findViewById(R.id.category);
        final RatingBar rating = findViewById(R.id.rating);

        name.setText("Name: "+temp.getName());
        phone.setText("Phone #: "+temp.getNum());
        web.setText("Website: "+temp.getWeb());
        category.setText("Category: "+temp.getCategory());
        rating.setRating(temp.rating);

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewRestaurant.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
