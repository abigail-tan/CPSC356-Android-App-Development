package edu.chapman.tan177.assignment4;

import java.util.ArrayList;

public class Restaurant {

    public static ArrayList<Restaurant> restaurantList = new ArrayList<Restaurant>();

    public String name;
    public String phone;
    public String web;
    public String category;
    public float rating;

    public Restaurant(String restName, String phoneNum, String website,
                      String cuisine, float rate)
    {
        this.name = restName;
        this.phone = phoneNum;
        this.web = website;
        this.category = cuisine;
        this.rating = rate;
    }

    public String getName()
    {
        return this.name;
    }

    public String getNum()
    {
        return this.phone;
    }

    public String getWeb()
    {
        return this.web;
    }

    public String getCategory()
    {
        return this.category;
    }

    public float getRating()
    {
        return this.rating;
    }

}
