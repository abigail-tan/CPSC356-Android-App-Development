package edu.chapman.tan177.assignment4;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    public static ArrayList<Button> buttons = new ArrayList<Button>();
    public static int id;
    public LinearLayout mainLayout;

    public static boolean removeNum = false;
    public static boolean removeCategory = false;
    public static boolean removeWebsite = false;
    //public static boolean aboveThree = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainLayout = findViewById(R.id.activity_main);

        if(Restaurant.restaurantList.size() > 0)
        {
            TextView initial = findViewById(R.id.initial);
            initial.setVisibility(View.GONE);
            viewRestaurants();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.my_menu,menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch(id)
        {
            case R.id.add:
                Intent intent = new Intent(this, Add.class);
                startActivity(intent);
                break;
            case R.id.clear:
                clearRestaurants();
                break;
            case R.id.preferences:
                Intent intent2 = new Intent(this, Preferences.class);
                startActivity(intent2);
                break;
            case R.id.sortAlph:
                sortAlpha();
                break;
            case R.id.sortRate:
                sortRate();
                break;
            default:
                break;
        }

        return true;
    }

    public void viewRestaurants()
    {
        for(int i = 0; i< Restaurant.restaurantList.size(); ++i)
        {
            final Button btn = new Button(MainActivity.this);
            btn.setHeight(30);
            btn.setId(i);
            id = i;
            String name = Restaurant.restaurantList.get(i).getName();
            String phone = Restaurant.restaurantList.get(i).getNum();
            String web = Restaurant.restaurantList.get(i).getWeb();
            String category = Restaurant.restaurantList.get(i).getCategory();
            float rating = Restaurant.restaurantList.get(i).getRating();
            String temp ="";

            if(removeNum)
                temp = name+" "+web+" "+category+" Rating: "+rating;

            if(removeWebsite)
                temp = name+" "+phone+" "+category+" Rating: "+rating;
            if(removeNum && removeWebsite)
                temp = name+" "+category+" Rating: "+rating;

            if(removeCategory)
                temp = name+" "+phone+" "+web+" Rating: "+rating;
            if(removeCategory && removeNum)
                temp = name+" "+web+" Rating: "+rating;
            if(removeCategory && removeWebsite)
                temp = name+" "+phone+" Rating: "+rating;

            if(!removeWebsite && !removeCategory && !removeNum)
                temp = name+" "+phone+" "+web+" "+category+" Rating: "+rating;


            btn.setText(temp);
            //if(aboveThree)
              //  setAboveThree();
            buttons.add(btn);
            mainLayout.addView(btn);
        }


        for(int i=0; i<buttons.size(); ++i)
        {
            buttons.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity.this, ViewRestaurant.class);
                    startActivity(intent);
                }
            });
        }
    }

    public void sortAlpha()
    {
        Collections.sort(Restaurant.restaurantList, new Comparator<Restaurant>() {
            public int compare(Restaurant r1, Restaurant r2) {
                return r1.getName().compareTo(r2.getName());
            }
        });

        for(int i=0; i<buttons.size(); ++i)
        {
            mainLayout.removeAllViews();
            buttons.clear();
        }

        viewRestaurants();
    }

    public void sortRate()
    {
        Collections.sort(Restaurant.restaurantList, new Comparator<Restaurant>() {
            public int compare(Restaurant r1, Restaurant r2) {
                return (r1.getRating() < r2.getRating() ? -1 :
                        (r2.getRating() == r1.getRating() ? 0 : 1));
            }
        });

        for(int i=0; i<buttons.size(); ++i)
        {
            mainLayout.removeAllViews();
            buttons.clear();
        }

        viewRestaurants();
    }

    /*public void setAboveThree()
    {
        for(int i=0; i < buttons.size(); ++i)
        {
            if(Restaurant.restaurantList.get(i).getRating() < 3.0)
                buttons.get(i).setVisibility(View.GONE);
        }
    }*/


    public void clearRestaurants()
    {
        Restaurant.restaurantList.clear();
        buttons.clear();
        mainLayout.removeAllViews();
    }
}
