package edu.chapman.tan177.assignment4;

import android.Manifest;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class Add extends AppCompatActivity {


    String phone;
    String web;
    String category;
    float rating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        final Button addBtn = findViewById(R.id.add);
        final EditText restName = findViewById(R.id.restName);
        final EditText phoneNum = findViewById(R.id.phoneNum);
        final EditText website = findViewById(R.id.website);
        final RatingBar rate = findViewById(R.id.ratingBar);

        final Spinner categoryList = findViewById(R.id.spinner);
        List<String> cuisineList = new ArrayList<String>();
        cuisineList.add("American");
        cuisineList.add("Chinese");
        cuisineList.add("French");
        cuisineList.add("German");
        cuisineList.add("Greek");
        cuisineList.add("Indian");
        cuisineList.add("Italian");
        cuisineList.add("Japanese");
        cuisineList.add("Korean");
        cuisineList.add("Mediterranean");
        cuisineList.add("Mexican");
        cuisineList.add("Thai");
        cuisineList.add("Vietnamese");
        cuisineList.add("Other");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, cuisineList);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categoryList.setAdapter(dataAdapter);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {String name;
                name = restName.getText().toString();
                phone = phoneNum.getText().toString();
                web = website.getText().toString();
                category = String.valueOf(categoryList.getSelectedItem());
                rating = rate.getRating();

                Restaurant temp = new Restaurant(name, phone, web, category, rating);
                Restaurant.restaurantList.add(temp);
                Intent intent = new Intent(Add.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
