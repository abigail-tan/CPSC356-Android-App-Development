package edu.chapman.tan177.assignment4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class Preferences extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferences);

        MainActivity.removeNum = false;
        MainActivity.removeWebsite = false;
        MainActivity.removeCategory = false;
        //MainActivity.aboveThree = false;

        final Button backBtn = findViewById(R.id.back);

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Preferences.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }

    public void onCheckboxClicked(View view) {
        // Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();

        // Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.noNum:
                if (checked)
                    MainActivity.removeNum = true;
                else
                    MainActivity.removeNum = false;
                break;
            case R.id.noWeb:
                if (checked)
                    MainActivity.removeWebsite = true;
                else
                    MainActivity.removeWebsite = false;
                break;
             case R.id.noCat:
                if (checked)
                    MainActivity.removeCategory = true;
                else
                    MainActivity.removeCategory = false;
                    break;
            /*case R.id.niceRest:
                if (checked)
                    MainActivity.aboveThree = true;
                else
                    MainActivity.aboveThree = false;
                    break;*/
            default:
                    break;
        }
    }
}
